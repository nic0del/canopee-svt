
A1 = str(input("entrer le nom de l'allèle dominant"))
A2 = str(input("entrer le nom de l'allèle récessif"))
M = float(input("Donner l'effectif du phénotype homozygote pour l'allèle dominant : "))
P = float(input("Donner l'effectif du phénotype hétérozygote : "))
S = float(input("Donner l'effectif du second phénotype homozygote pour l'allèle récessif : "))
T = M+S+P


B1 = ((2*M+P)/(2*T))*((2*M+P)/(2*T))
B2 = ((2*(2*M+P)/(2*T)))*((2*S+P)/(2*T))
B3 = ((2*S+P)/(2*T))*((2*S+P)/(2*T))

C1 = M/T
C2 = P/T
C3 = S/T

print ("La fréquence théorique du génotype ( ", A1,"//", A1," ) selon le modèle  de Hardy Weinberg est de " , B1," alors que celle observée dans la population est de ",C1)
print ("L'effectif théorique du génotype ( ", A1,"//", A2," ) selon le modèle de Hardy Weinberg est de " , B2," alors que celle observée dans la population est de ",C2)
print ("L'effectif théorique du génotype ( ", A2,"//" ,A2," ) selon le modèle de Hardy Weinberg est de " , B3," alors que celle observée dans la population est de ",C3)